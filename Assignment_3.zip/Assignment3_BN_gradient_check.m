%Loading and Storing data
[Xt, Yt, yt] = LoadBatch('data_batch_1');
[Xv, Yv, yv] = LoadBatch('data_batch_2');
[Xc, Yc, yc] = LoadBatch ('test_batch.mat');
%Data normalization
mean_X = mean(Xt, 2);
std_X = std(Xt, 0, 2);
Xt = Xt - repmat(mean_X, [1, size(Xt, 2)]);
Xt = Xt ./ repmat(std_X, [1, size(Xt, 2)]);
Xv = Xv - repmat(mean_X, [1, size(Xv, 2)]);
Xv = Xv ./ repmat(std_X, [1, size(Xv, 2)]);
Xc = Xc - repmat(mean_X, [1, size(Xc, 2)]);
Xc = Xc ./ repmat(std_X, [1, size(Xc, 2)]);
m = [50,50]; %number of hidden nodes
K = max(yt); %number of classes
d = size(Xt,1);
N = size(Xt,2);
lambda = 0;
[error_W1,error_b1,error_gamma1,error_beta1,error_W2,error_b2,error_gamma2,error_beta2,error_W3,error_b3] = gradient_error(Xt(:,1:100), Yt(:,1:100), m, K, d, lambda);

function [error_W1,error_b1,error_gamma1,error_beta1,error_W2,error_b2,error_gamma2,error_beta2,error_W3,error_b3] = gradient_error(X, Y, m, K, d, lambda)
h = 1e-5;
[W, b, gamma, beta] = initialize(m,K,d);
NetParams = struct;
NetParams.W = W;
NetParams.b = b;
NetParams.gammas = gamma;
NetParams.betas = beta;
NetParams.use_bn = 1;
[P, Xb, s, scap, mu, v] = EvaluateClassifier(X,W,b,gamma,beta);
[agW,agb, agG,agBe] = ComputeGradients(X, Y, P, Xb, s, scap, W, gamma, mu, v, lambda);
Grads = ComputeGradsNumSlow(X, Y, NetParams, lambda, h);
epsilon = 0.00001;
for i = 1:4
    error_b1(i) = max(abs(agb{1}-Grads.b{1})./max(epsilon,abs(agb{1})+abs(Grads.b{1})));
    error_W1(i) = max(max(max(abs(agW{1}-Grads.W{1}))./max(epsilon,abs(agW{1})+abs(Grads.W{1}))));
    error_beta1(i) = max(abs(agBe{1}-Grads.betas{1})./max(epsilon,abs(agBe{1})+abs(Grads.betas{1})));
    error_gamma1(i) = max(max(max(abs(agG{1}-Grads.gammas{1}))./max(epsilon,abs(agG{1})+abs(Grads.gammas{1}))));
    error_b2(i) = max(abs(agb{2}-Grads.b{2})./max(epsilon,abs(agb{2})+abs(Grads.b{2})));
    error_W2(i) = max(max(max(abs(agW{2}-Grads.W{2}))./max(epsilon,abs(agW{2})+abs(Grads.W{2}))));
    error_beta2(i) = max(abs(agBe{2}-Grads.betas{2})./max(epsilon,abs(agBe{2})+abs(Grads.betas{2})));
    error_gamma2(i) = max(max(max(abs(agG{2}-Grads.gammas{2}))./max(epsilon,abs(agG{2})+abs(Grads.gammas{2}))));
    error_b3(i) = max(abs(agb{3}-Grads.b{3})./max(epsilon,abs(agb{3})+abs(Grads.b{3})));
    error_W3(i) = max(max(max(abs(agW{3}-Grads.W{3}))./max(epsilon,abs(agW{3})+abs(Grads.W{3}))));
    epsilon = epsilon*10;
end
end

% GDparams = struct;
% GDparams.eta_min = 1e-5;
% GDparams.eta_max = 1e-1;
% GDparams.n_batch = 100;
% GDparams.cycles = 2;
% GDparams.updateStep = 5 *(N/GDparams.n_batch);
% GDparams.eta = zeros(1,(2*GDparams.cycles*GDparams.updateStep));
% GDparams.lambda=0.005;



function [W, b, GDparams, Jt, Jv, lt, lv, acc_t, acc_v,mu_av,v_av] = MiniBatchGD(X, Y, y, Xv, Yv, yv, GDparams, W, b, gamma, beta)
Jt = zeros(1,11); lt = zeros(1,11); acc_t = zeros(1,11);
Jv = zeros(1,11); lv = zeros(1,11); acc_v = zeros(1,11);
count = 1;
dataSize = size(X,2);
layer = size(W,2);
for i = 1 : 2*GDparams.cycles*GDparams.updateStep
    for L = 0:GDparams.cycles
        if((i>=(2*L*GDparams.updateStep)) && (i<= ((2*L+1)*GDparams.updateStep)))
            e1 = (i - (2*L*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_min + (e1*e2);
        elseif((i >= ((2*L+1)*GDparams.updateStep)) && (i<=(2*(L+1)*GDparams.updateStep)))
            e1 = (i - ((2*L+1)*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_max - (e1*e2);
        end
    end
    if (i <= dataSize/GDparams.n_batch)
        j = i;
    elseif (i>dataSize/GDparams.n_batch)
        j = rem(i,dataSize/GDparams.n_batch);
        if (j == 0)
            j = dataSize/GDparams.n_batch;
        end
    end
    if (j == 1)
       shuffle = randperm(dataSize/GDparams.n_batch);
    end
    js = shuffle(j);
    j_start = (js-1)*GDparams.n_batch + 1;
    j_end = js*GDparams.n_batch;
    inds = j_start:j_end;
    Xbatch = X(:, inds);
    Ybatch = Y(:, inds);
    [P, Xb, s, scap, mu, v] = EvaluateClassifier(X, W, b, gamma, beta);
    for a = 1:layer-1
        if (j==1)
            mu_av = mu;
            v_av = v;
        else
            mu_av{a} = (alpha*mu_av{a}) + ((1-alpha)*mu{a});
            v_av{a} = (alpha*v_av{a}) + ((1-alpha)*v{a});
        end
    end
    [grad_W, grad_b, grad_G, grad_Be] = ComputeGradients(X, Y, P, Xb, s, scap, W, gamma, mu, v, lambda);
    for k = 1:layer
        W{k} = W{k} - GDparams.eta(i)*grad_W{k};
        b{k} = b{k} - GDparams.eta(i)*grad_b{k};
        if (k<layer)
            gamma{k} = W{k} - GDparams.eta(i)*grad_G{k};
            beta{k} = b{k} - GDparams.eta(i)*grad_Be{k};
        end 
    end
    if (i==1 || rem(i,GDparams.n_batch) == 0)
        [Jt(count),lt(count)]  = ComputeCost(X, Y, W, b, gamma, beta, GDparams.lambda,mu_av, v_av);
        [Jv(count),lv(count)]  = ComputeCost(Xv, Yv, W, b, gamma, beta, GDparams.lambda, mu_av, v_av);
        acc_t(count) = ComputeAccuracy(X, y, W, b,gamma,beta,mu_av,v_av);
        acc_v(count) = ComputeAccuracy(Xv, yv, W, b,gamma,beta,mu_av,v_av); 
        count = count +1;
    end
end
end

function acc = ComputeAccuracy(X, y, W, b, gamma, beta, mu_av, v_av)
[P,~] = EvaluateClassifier(X,W,b,gamma,beta, mu_av, v_av);
[~ , index] = max(P);
count = 0;
for i = 1:size(X,2)
   if index(i) == y(i)
      count = count+1;
   end
end
acc = 100 * count/size(X,2);
end


function [J] = ComputeCost(varargin)
X = varargin{1};
Y = varargin{2}; 
W = varargin{3};
b = varargin{4}; 
gamma = varargin{5};
beta = varargin{6};
lambda = varargin{7};

if nargin == 9
    mu_av = varargin{8};
    v_av = varargin{9};
    [P, ~] = EvaluateClassifier(X, W, b, gamma, beta, mu_av, v_av);
else
    [P, ~] = EvaluateClassifier(X, W, b, gamma, beta);
end
    
layer = size(W,2);
Wsum = 0;
Lcross = (-Y.*log(P))/size(X,2);
loss = sum(sum(Lcross));
for i = 1:layer
    Wsum = Wsum + sumsqr(W{i});
end
J = loss + (lambda * Wsum);
end
%Gradient computation
function [grad_W, grad_b, grad_G, grad_Be] = ComputeGradients(X, Y, P, Xb, s, scap, W, gamma, mu, v, lambda)

N = size(X,2);
I = ones(N,1);
layer = size(W,2);
grad_W = cell(1,layer);
grad_b = cell(1,layer);
grad_G = cell(1,layer-1);
grad_Be = cell(1,layer-1);

G = -(Y-P);
grad_W{layer} = (G*(Xb{layer-1})')/N + 2*lambda*W{layer};
grad_b{layer} = (G*I)/N;
G = W{layer}'*G;
Xtemp = Xb{layer-1};
Xtemp(Xtemp>0) = 1;
G = G .* Xtemp;

for l = layer-1:-1:1
    grad_G{l} = ((G.*scap{l})*I)/N;
    grad_Be{l} = (G*I)/N;
    G = G.*(gamma{l}*I');
    G = BatchNormBackPass(G,s{l}, mu{l}, v{l});
    if(l==1)
        grad_W{l} = (G*(X)')/N + (2*lambda*W{l});
        grad_b{l} = (G*I)/N;
    else
        grad_W{l} = (G*(Xb{l-1})')/N + (2*lambda*W{l});
        grad_b{l} = (G*I)/N;
    end
    if (l>1)
      G = W{l}'*G;
      Xtemp = Xb{l-1};
      Xtemp(Xtemp>0) = 1;
      G = G .* Xtemp;
    end
end
end

function Gbatch = BatchNormBackPass(G,s, mu, v)
N = size(G,2);
I = ones(N,1);
sig1 = (v+eps).^(-0.5);
sig2 = (v+eps).^(-1.5);
G1 = G.*(sig1*I');
G2 = G.*(sig2*I');
D = s - mu*I';
c = (G2.*D)*I;
p1 = ((G1*I)*I')/N;
p2 = (D.*(c*I'))/N;
Gbatch = G1 - p1 - p2;
end

%Evaluating Classifier function
function [P, Xb, s, scap, mu, v] = EvaluateClassifier(varargin)
%the b vector gets repmat'ed during the addition process,so no repmat fn is explicitly used
X = varargin{1};
W = varargin{2};
b = varargin{3};
gamma = varargin{4};
beta = varargin{5};
layer = size(W,2);
N = size(X,2);
s= cell(1,layer);
mu= cell(1,layer-1);
v = cell (1,layer-1);
scap = cell(1,layer-1);
sbar = cell(1,layer-1);
Xb = cell(1,layer-1);
for l = 1: layer-1
       if l == 1
           s{l} = W{l}*X + b{l};
       else
           s{l} = W{l}*Xb{l-1}+ b{l};
       end
       if nargin == 5
           mu{l} = sum(s{l},2)/N;
           v{l} = (sum((s{l}- mu{l}).^2 , 2))/N;
       elseif nargin == 7
            mu{l} = varargin{6};
            v{l} = varargin {7};
       end
       scap{l} = ((diag (v{l}+eps))^-0.5) * (s{l} - mu{l});
       sbar{l} = gamma{l}.*scap{l} + beta{l};
       Xb{l} = max(0,sbar{l});
end
s{layer} = W{layer} * Xb{layer-1} + b{layer};
exp_s = exp(s{layer});
sum_s = sum(exp_s);
P = exp_s ./ sum_s;
end

function [W, b, gamma, beta] = initialize(m,K,d)
rng(400);
layer = size(m,2)+1;
W = cell(1,layer);
b = cell(1,layer);
gamma = cell(1,layer-1);
beta = cell(1,layer-1);
for i = 1:layer
    if (i==1)
        W{i} = randn(m(i),d) * (1/sqrt(d));
        b{i} = zeros(m(i),1);
        gamma{i} = ones(m(i),1);
        beta{i} = zeros(m(i),1);
    elseif (i==layer)
        W{i} = randn(K,m(i-1)) * (1/sqrt(m(i-1)));
        b{i} = zeros(K,1);
    else
        W{i} = randn(m(i),m(i-1))* (1/sqrt(m(i-1)));
        b{i} = zeros(m(i),1);
        gamma{i} = ones(m(i),1);
        beta{i} = zeros(m(i),1);
    end    
end
end

function [X, Y, y] = LoadBatch(filename)
A = load(filename);
X = (double(A.data'))/255;
y = double(A.labels') + 1;
Y = zeros(max(y),size(X,2));
for i=1:size(X,2)
    temp = y(i);
    for j = 1:max(y)
        if (temp == j)
            Y(j,i) = 1;
        end
    end
end
end

function Grads = ComputeGradsNumSlow(X, Y, NetParams, lambda, h)

Grads.W = cell(numel(NetParams.W), 1);
Grads.b = cell(numel(NetParams.b), 1);
if NetParams.use_bn
    Grads.gammas = cell(numel(NetParams.gammas), 1);
    Grads.betas = cell(numel(NetParams.betas), 1);
end

for j=1:length(NetParams.b)
    Grads.b{j} = zeros(size(NetParams.b{j}));
    NetTry = NetParams;
    for i=1:length(NetParams.b{j})
        b_try = NetParams.b;
        b_try{j}(i) = b_try{j}(i) - h;
        NetTry.b = b_try;
        c1 = ComputeCost(X, Y, NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);        
        
        b_try = NetParams.b;
        b_try{j}(i) = b_try{j}(i) + h;
        NetTry.b = b_try;        
        c2 = ComputeCost(X, Y, NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);
        
        Grads.b{j}(i) = (c2-c1) / (2*h);
    end
end

for j=1:length(NetParams.W)
    Grads.W{j} = zeros(size(NetParams.W{j}));
        NetTry = NetParams;
    for i=1:numel(NetParams.W{j})
        
        W_try = NetParams.W;
        W_try{j}(i) = W_try{j}(i) - h;
        NetTry.W = W_try;        
        c1 = ComputeCost(X, Y, NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);
    
        W_try = NetParams.W;
        W_try{j}(i) = W_try{j}(i) + h;
        NetTry.W = W_try;        
        c2 = ComputeCost(X, Y,NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);
    
        Grads.W{j}(i) = (c2-c1) / (2*h);
    end
end

if NetParams.use_bn
    for j=1:length(NetParams.gammas)
        Grads.gammas{j} = zeros(size(NetParams.gammas{j}));
        NetTry = NetParams;
        for i=1:numel(NetParams.gammas{j})
            
            gammas_try = NetParams.gammas;
            gammas_try{j}(i) = gammas_try{j}(i) - h;
            NetTry.gammas = gammas_try;        
            c1 = ComputeCost(X, Y, NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);
            
            gammas_try = NetParams.gammas;
            gammas_try{j}(i) = gammas_try{j}(i) + h;
            NetTry.gammas = gammas_try;        
            c2 = ComputeCost(X, Y, NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);
            
            Grads.gammas{j}(i) = (c2-c1) / (2*h);
        end
    end
    
    for j=1:length(NetParams.betas)
        Grads.betas{j} = zeros(size(NetParams.betas{j}));
        NetTry = NetParams;
        for i=1:numel(NetParams.betas{j})
            
            betas_try = NetParams.betas;
            betas_try{j}(i) = betas_try{j}(i) - h;
            NetTry.betas = betas_try;        
            c1 = ComputeCost(X, Y, NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);
            
            betas_try = NetParams.betas;
            betas_try{j}(i) = betas_try{j}(i) + h;
            NetTry.betas = betas_try;        
            c2 = ComputeCost(X, Y, NetTry.W, NetTry.b,NetTry.gammas,NetTry.betas, lambda);
            
            Grads.betas{j}(i) = (c2-c1) / (2*h);
        end
    end    
end
end
