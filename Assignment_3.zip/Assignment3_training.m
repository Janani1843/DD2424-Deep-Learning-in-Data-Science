%Loading and Storing data
filename = {'data_batch_1','data_batch_2','data_batch_3','data_batch_4','data_batch_5'};
[Xc, Yc, yc] = LoadBatch('test_batch');
for i = (1:5)
    [X, Y, y] = LoadBatch(char(filename(i)));
    if (i == 1)
        Xt = X(:,1:10000);
        Yt = Y(:,1:10000);
        yt = y(:,1:10000);
    elseif (i>1 && i<5)
        Xt = [Xt X(:,1:10000)];
        Yt = [Yt Y(:,1:10000)];
        yt = [yt y(:,1:10000)];
    elseif (i == 5)
        Xt = [Xt X(:,1:5000)];
        Xv = X(:,5001:10000);
        Yt = [Yt Y(:,1:5000)];
        Yv = Y(:,5001:10000);
        yt = [yt y(:,1:5000)];
        yv = y(:,5001:10000);
    end
end

%Data normalization
mean_X = mean(Xt, 2);
std_X = std(Xt, 0, 2);
Xt = Xt - repmat(mean_X, [1, size(Xt, 2)]);
Xt = Xt ./ repmat(std_X, [1, size(Xt, 2)]);
Xv = Xv - repmat(mean_X, [1, size(Xv, 2)]);
Xv = Xv ./ repmat(std_X, [1, size(Xv, 2)]);
Xc = Xc - repmat(mean_X, [1, size(Xc, 2)]);
Xc = Xc ./ repmat(std_X, [1, size(Xc, 2)]);
m = [50,50]; %number of hidden nodes
K = max(yt); %number of classes
d = size(Xt,1);
N = size(Xt,2);
[W, b] = initialize(m,K,d);
GDparams = struct;
GDparams.eta_min = 1e-5;
GDparams.eta_max = 1e-1;
GDparams.n_batch = 100;
GDparams.cycles = 2;
GDparams.updateStep = 5 *(N/GDparams.n_batch);
GDparams.eta = zeros(1,(2*GDparams.cycles*GDparams.updateStep));
GDparams.lambda=0.005;
[W, b, GDparams, Jt, Jv, lt, lv, acc_t, acc_v] = MiniBatchGD(Xt, Yt, yt, Xv, Yv, yv, GDparams, W, b);
acc_test = ComputeAccuracy(Xc, yc, W, b);


function [W, b, GDparams, Jt, Jv, lt, lv, acc_t, acc_v] = MiniBatchGD(X, Y, y, Xv, Yv, yv, GDparams, W, b)
Jt = zeros(1,11); lt = zeros(1,11); acc_t = zeros(1,11);
Jv = zeros(1,11); lv = zeros(1,11); acc_v = zeros(1,11);
count = 1;
dataSize = size(X,2);
for i = 1 : 2*GDparams.cycles*GDparams.updateStep
    for L = 0:GDparams.cycles
        if((i>=(2*L*GDparams.updateStep)) && (i<= ((2*L+1)*GDparams.updateStep)))
            e1 = (i - (2*L*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_min + (e1*e2);
        elseif((i >= ((2*L+1)*GDparams.updateStep)) && (i<=(2*(L+1)*GDparams.updateStep)))
            e1 = (i - ((2*L+1)*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_max - (e1*e2);
        end
    end

    if (i==1 || rem(i,GDparams.n_batch) == 0)
        [Jt(count),lt(count)]  = ComputeCost(X, Y, W, b, GDparams.lambda);
        [Jv(count),lv(count)]  = ComputeCost(Xv, Yv, W, b, GDparams.lambda);
        acc_t(count) = ComputeAccuracy(X, y, W, b);
        acc_v(count) = ComputeAccuracy(Xv, yv, W, b); 
        count = count +1;
    end
    if (i <= dataSize/GDparams.n_batch)
        j = i;
    elseif (i>dataSize/GDparams.n_batch)
        j = rem(i,dataSize/GDparams.n_batch);
        if (j == 0)
            j = dataSize/GDparams.n_batch;
        end
    end
    if (j == 1)
       shuffle = randperm(dataSize/GDparams.n_batch);
    end
    js = shuffle(j);
    j_start = (js-1)*GDparams.n_batch + 1;
    j_end = js*GDparams.n_batch;
    inds = j_start:j_end;
    Xbatch = X(:, inds);
    Ybatch = Y(:, inds);
    [P, Xb] = EvaluateClassifier(Xbatch, W, b);
    [grad_W, grad_b] = ComputeGradients(Xbatch,Ybatch, P, Xb, W, GDparams.lambda);
    layer = size(W,2);
    for k = 1:layer
        W{k} = W{k} - GDparams.eta(i)*grad_W{k};
        b{k} = b{k} - GDparams.eta(i)*grad_b{k};
    end     
end
end

function acc = ComputeAccuracy(X, y, W, b)
P = EvaluateClassifier(X,W,b);
[~ , index] = max(P);
count = 0;
for i = 1:size(X,2)
   if index(i) == y(i)
      count = count+1;
   end
end
acc = 100 * count/size(X,2);
end

%Gradient computation
function [grad_W, grad_b] = ComputeGradients(X,Y, P,Xb, W, lambda)
G = -(Y-P);
N = size(X,2);
I = ones(N,1);
layer = size(W,2);
grad_W = cell(1,layer);
grad_b = cell(1,layer);
for l = layer:-1:2
    grad_W{l} = (G*(Xb{l-1}'))/N + (2*lambda*W{l});
    grad_b{l} = (G*I)/N;
    G = (W{l})'*G;
    Xtemp = Xb{l-1};
    Xtemp(Xtemp>0) = 1;
    G = G .* Xtemp;
end
grad_W{1} = (G*X')/N +(2*lambda*W{1});
grad_b{1} = (G*I)/N;
end
function [J,loss] = ComputeCost(X, Y, W, b, lambda)
layer = size(W,2);
Wsum = 0;
[P, ~] = EvaluateClassifier(X, W, b);
Lcross = (-Y.*log(P))/size(X,2);
loss = sum(sum(Lcross));
for i = 1:layer
    Wsum = Wsum + sumsqr(W{i});
end
J = loss + (lambda * Wsum);
end
%Evaluating Classifier function
function [P, Xb] = EvaluateClassifier(X, W, b)
%the b vector gets repmat'ed during the addition process,so no repmat fn is explicitly used
layer = size(W,2);
Xb = cell(1,layer);
for i = 1: layer-1
    if (i == 1)
        Xbatch = max(0,(W{i}*X + b{i}));
        Xb{i} = Xbatch;
    else
        Xbatch = max(0,(W{i}*Xbatch + b{i}));
        Xb{i} = Xbatch;
    end
end
s = W{layer}*Xbatch + b{layer};
exp_s = exp(s);
sum_s = sum(exp_s);
P = exp_s ./ sum_s;
end

function [W, b] = initialize(m,K,d)
rng(400);
layer = size(m,2)+1;
W = cell(1,layer);
b = cell(1,layer);
for i = 1:layer
    if (i==1)
        W{i} = randn(m(i),d) * (1/sqrt(d));
        b{i} = zeros(m(i),1);
    elseif (i==layer)
        W{i} = randn(K,m(i-1)) * (1/sqrt(m(i-1)));
        b{i} = zeros(K,1);
    else
        W{i} = randn(m(i),m(i-1))* (1/sqrt(m(i-1)));
        b{i} = zeros(m(i),1);
    end
end
end

function [X, Y, y] = LoadBatch(filename)
A = load(filename);
X = (double(A.data'))/255;
y = double(A.labels') + 1;
Y = zeros(max(y),size(X,2));
for i=1:size(X,2)
    temp = y(i);
    for j = 1:max(y)
        if (temp == j)
            Y(j,i) = 1;
        end
    end
end
end


