%Loading and Storing data
[Xt, Yt, yt] = LoadBatch('data_batch_1');
[Xv, Yv, yv] = LoadBatch('data_batch_2');
[Xc, Yc, yc] = LoadBatch ('test_batch.mat');

%Data normalization
mean_X = mean(Xt, 2);
std_X = std(Xt, 0, 2);
Xt = Xt - repmat(mean_X, [1, size(Xt, 2)]);
Xt = Xt ./ repmat(std_X, [1, size(Xt, 2)]);
Xv = Xv - repmat(mean_X, [1, size(Xv, 2)]);
Xv = Xv ./ repmat(std_X, [1, size(Xv, 2)]);
Xc = Xc - repmat(mean_X, [1, size(Xc, 2)]);
Xc = Xc ./ repmat(std_X, [1, size(Xc, 2)]);
m = [50, 50, 50]; %number of hidden nodes
K = max(yt); %number of classes
d = size(Xt,1);
lambda = 0;
[error_W1,error_W2,error_W3,error_W4,error_b1,error_b2,error_b3,error_b4] = gradient_error(Xt(:,100), Yt(:,100), m, K, d, lambda);

function acc = ComputeAccuracy(X, y, W, b)
P = EvaluateClassifier(X,W,b);
[~ , index] = max(P);
count = 0;
for i = 1:size(X,2)
   if index(i) == y(i)
      count = count+1;
   end
end
acc = 100 * count/size(X,2);
end

%Gradient computation
function [grad_W, grad_b] = ComputeGradients(X, Xb, Y, P, W)
G = -(Y-P);
N = size(X,2);
I = ones(N,1);
layer = size(W,2);
grad_W = cell(1,layer);
grad_b = cell(1,layer);
for l = layer:-1:2
    grad_W{l} = (G*(Xb{l-1}'))/N;
    grad_b{l} = (G*I)/N;
    G = (W{l})'*G;
    Xtemp = Xb{l-1};
    Xtemp(Xtemp>0) = 1;
    G = G .* Xtemp;
end
grad_W{1} = (G*X')/N;
grad_b{1} = (G*I)/N;
end
function J = ComputeCost(X, Y, W, b, lambda)
layer = size(W,2);
Wsum = 0;
[P, ~] = EvaluateClassifier(X, W, b);
Lcross = (-Y.*log(P))/size(X,2);
for i = 1:layer
    Wsum = Wsum + sumsqr(W{i});
end
J = sum(sum(Lcross)) + (lambda * Wsum);
end
%Evaluating Classifier function
function [P, Xb] = EvaluateClassifier(X, W, b)
%the b vector gets repmat'ed during the addition process,so no repmat fn is explicitly used
layer = size(W,2);
Xb = cell(1,layer);
for i = 1: layer-1
    if (i == 1)
        Xbatch = max(0,(W{i}*X + b{i}));
        Xb{i} = Xbatch;
    else
        Xbatch = max(0,(W{i}*Xbatch + b{i}));
        Xb{i} = Xbatch;
    end
end
s = W{layer}*Xbatch + b{layer};
exp_s = exp(s);
sum_s = sum(exp_s);
P = exp_s ./ sum_s;
end

function [W, b] = initialize(m,K,d)
rng(400);
layer = size(m,2)+1;
W = cell(1,layer);
b = cell(1,layer);
for i = 1:layer
    if (i==1)
        W{i} = randn(m(i),d) * (1/sqrt(d));
        b{i} = zeros(m(i),1);
    elseif (i==layer)
        W{i} = randn(K,m(i-1)) * (1/sqrt(m(i-1)));
        b{i} = zeros(K,1);
    else
        W{i} = randn(m(i),m(i-1))* (1/sqrt(m(i-1)));
        b{i} = zeros(m(i),1);
    end
end
end

function [X, Y, y] = LoadBatch(filename)
A = load(filename);
X = (double(A.data'))/255;
y = double(A.labels') + 1;
Y = zeros(max(y),size(X,2));
for i=1:size(X,2)
    temp = y(i);
    for j = 1:max(y)
        if (temp == j)
            Y(j,i) = 1;
        end
    end
end
end

function [error_W1,error_W2,error_W3,error_W4,error_b1,error_b2,error_b3,error_b4] = gradient_error(X, Y, m, K, d, lambda)
h = 1e-5;
[W, b] = initialize(m,K,d);
[P,Xb] = EvaluateClassifier(X, W, b);
[agW,agb] = ComputeGradients(X, Xb, Y, P, W);
[ngW,ngb] = ComputeGradsNumSlow(X, Y, W, b, lambda, h);
epsilon = 0.00001;
for i = 1:4
    error_b1(i) = max(abs(agb{1}-ngb{1})./max(epsilon,abs(agb{1})+abs(ngb{1})));
    error_W1(i) = max(max(max(abs(agW{1}-ngW{1}))./max(epsilon,abs(agW{1})+abs(ngW{1}))));
    error_b2(i) = max(abs(agb{2}-ngb{2})./max(epsilon,abs(agb{2})+abs(ngb{2})));
    error_W2(i) = max(max(max(abs(agW{2}-ngW{2}))./max(epsilon,abs(agW{2})+abs(ngW{2}))));
    error_b3(i) = max(abs(agb{3}-ngb{3})./max(epsilon,abs(agb{3})+abs(ngb{3})));
    error_W3(i) = max(max(max(abs(agW{3}-ngW{3}))./max(epsilon,abs(agW{3})+abs(ngW{3}))));
    error_b4(i) = max(abs(agb{4}-ngb{4})./max(epsilon,abs(agb{4})+abs(ngb{4})));
    error_W4(i) = max(max(max(abs(agW{4}-ngW{4}))./max(epsilon,abs(agW{4})+abs(ngW{4}))));
    epsilon = epsilon*10;
end
end

function [grad_W, grad_b] = ComputeGradsNumSlow(X, Y, W, b, lambda, h)


grad_W = cell(numel(W), 1);
grad_b = cell(numel(b), 1);

for j=1:length(b)
    grad_b{j} = zeros(size(b{j}));
    
    for i=1:length(b{j})
        
        b_try = b;
        b_try{j}(i) = b_try{j}(i) - h;
        c1 = ComputeCost(X, Y, W, b_try, lambda);
        
        b_try = b;
        b_try{j}(i) = b_try{j}(i) + h;
        c2 = ComputeCost(X, Y, W, b_try, lambda);
        
        grad_b{j}(i) = (c2-c1) / (2*h);
    end
end

for j=1:length(W)
    grad_W{j} = zeros(size(W{j}));
    
    for i=1:numel(W{j})
        
        W_try = W;
        W_try{j}(i) = W_try{j}(i) - h;
        c1 = ComputeCost(X, Y, W_try, b, lambda);
    
        W_try = W;
        W_try{j}(i) = W_try{j}(i) + h;
        c2 = ComputeCost(X, Y, W_try, b, lambda);
    
        grad_W{j}(i) = (c2-c1) / (2*h);
    end
end
end