filename = {'data_batch_1','data_batch_2','data_batch_3','data_batch_4','data_batch_5'};
[Xc, Yc, yc] = LoadBatch('test_batch');
for i = (1:5)
    [X, Y, y] = LoadBatch(char(filename(i)));
    if (i == 1)
        Xt = X(:,1:10000);
        Yt = Y(:,1:10000);
        yt = y(:,1:10000);
    elseif (i>1 && i<5)
        Xt = [Xt X(:,1:10000)];
        Yt = [Yt Y(:,1:10000)];
        yt = [yt y(:,1:10000)];
    elseif (i == 5)
        Xt = [Xt X(:,1:5000)];
        Xv = X(:,5001:10000);
        Yt = [Yt Y(:,1:5000)];
        Yv = Y(:,5001:10000);
        yt = [yt y(:,1:5000)];
        yv = y(:,5001:10000);
    end
end

%Data normalization
mean_X = mean(Xt, 2);
std_X = std(Xt, 0, 2);
Xt = Xt - repmat(mean_X, [1, size(Xt, 2)]);
Xt = Xt ./ repmat(std_X, [1, size(Xt, 2)]);
Xv = Xv - repmat(mean_X, [1, size(Xv, 2)]);
Xv = Xv ./ repmat(std_X, [1, size(Xv, 2)]);
Xc = Xc - repmat(mean_X, [1, size(Xc, 2)]);
Xc = Xc ./ repmat(std_X, [1, size(Xc, 2)]);
m = [50, 30, 20, 20, 10, 10, 10, 10]; %number of hidden nodes
K = max(yt); %number of classes
d = size(Xt,1);
N = size(Xt,2);
GDparams = struct;
GDparams.eta_min = 1e-5;
GDparams.eta_max = 1e-1;
GDparams.n_batch = 100;
GDparams.cycles = 3;
GDparams.updateStep = 5 *(N/GDparams.n_batch);
GDparams.eta = zeros(1,(2*GDparams.cycles*GDparams.updateStep));
GDparams.lambda=0.00455344869218005;
[W, b, gamma, beta] = initialize(m,K,d);
[W, b, gamma, beta, GDparams, Jt, Jv, lt, lv, acc_t, acc_v,mu_av,v_av,epoch] = MiniBatchGD(Xt, Yt, yt, Xv, Yv, yv, GDparams, W, b, gamma, beta);
acc_test = ComputeAccuracy(Xc, yc, W, b,gamma,beta,mu_av,v_av);
xaxis = (0:100:2*GDparams.cycles*GDparams.updateStep);
figure(1)
plot(xaxis, Jt, 'r')
hold on
plot(xaxis, Jv, 'g')
hold off
xlabel('update step');
ylabel('cost');
legend('training cost', 'validation cost');
figure(2)
plot(xaxis, lt, 'r')
hold on
plot(xaxis, lv, 'g')
hold off
xlabel('update step');
ylabel('loss');
legend('training loss', 'validation loss');
figure(3)
plot(xaxis, acc_t, 'r')
hold on
plot(xaxis, acc_v, 'g')
hold off
xlabel('update step');
ylabel('accuracy');
legend('training accuracy', 'validation accuracy');

function [W, b,gamma, beta, GDparams, Jt, Jv, lt, lv, acc_t, acc_v,mu_av,v_av,epoch] = MiniBatchGD(X, Y, y, Xv, Yv, yv, GDparams, W, b, gamma, beta)
Jt = zeros(1,11); lt = zeros(1,11); acc_t = zeros(1,11);
Jv = zeros(1,11); lv = zeros(1,11); acc_v = zeros(1,11);
count = 1;
dataSize = size(X,2);
layer = size(W,2);
mu_av = cell(1,layer-1);
v_av = cell(1,layer-1);
alpha = 0.9;
lambda = GDparams.lambda;
epoch = 0;
for i = 1 : 2*GDparams.cycles*GDparams.updateStep
    for L = 0:GDparams.cycles
        if((i>=(2*L*GDparams.updateStep)) && (i<= ((2*L+1)*GDparams.updateStep)))
            e1 = (i - (2*L*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_min + (e1*e2);
        elseif((i >= ((2*L+1)*GDparams.updateStep)) && (i<=(2*(L+1)*GDparams.updateStep)))
            e1 = (i - ((2*L+1)*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_max - (e1*e2);
        end
    end
    
    if (i <= dataSize/GDparams.n_batch)
        j = i;
    elseif (i>dataSize/GDparams.n_batch)
        j = rem(i,dataSize/GDparams.n_batch);
        if (j == 0)
            j = dataSize/GDparams.n_batch;
        end
    end
    if (j == 1)
       shuffle = randperm(dataSize/GDparams.n_batch);
       epoch = epoch +1;
    end
    js = shuffle(j);
    j_start = (js-1)*GDparams.n_batch + 1;
    j_end = js*GDparams.n_batch;
    inds = j_start:j_end;
    Xbatch = X(:, inds);
    Ybatch = Y(:, inds);
    [P, Xb, s, scap, mu, v] = EvaluateClassifier(Xbatch, W, b, gamma, beta);
    [grad_W, grad_b, grad_G, grad_Be] = ComputeGradients(Xbatch, Ybatch, P, Xb, s, scap, W, gamma, mu, v, lambda);
    
    if (i==1)
        mu_av = mu;
        v_av = v;
    else
        for a = 1:layer-1
            mu_av{a} = (alpha*mu_av{a}) + ((1-alpha)*mu{a});
            v_av{a} = (alpha*v_av{a}) + ((1-alpha)*v{a});
        end
    end
    for k = 1:layer
        W{k} = W{k} - GDparams.eta(i)*grad_W{k};
        b{k} = b{k} - GDparams.eta(i)*grad_b{k};  
    end
    for k = 1:layer-1
            gamma{k} = gamma{k} - GDparams.eta(i)*grad_G{k};
            beta{k} = beta{k} - GDparams.eta(i)*grad_Be{k};
    end 
    if (i==1 || rem(i,GDparams.n_batch) == 0)
        [Jt(count),lt(count)]  = ComputeCost(X, Y, W, b, gamma, beta, GDparams.lambda,mu_av, v_av);
        [Jv(count),lv(count)]  = ComputeCost(Xv, Yv, W, b, gamma, beta, GDparams.lambda, mu_av, v_av);
        acc_t(count) = ComputeAccuracy(X, y, W, b,gamma,beta,mu_av,v_av);
        acc_v(count) = ComputeAccuracy(Xv, yv, W, b,gamma,beta,mu_av,v_av); 
        count = count +1;
    end
end
end

function acc = ComputeAccuracy(X, y, W, b, gamma, beta, mu_av, v_av)
[P,~] = EvaluateClassifier(X,W,b,gamma,beta, mu_av, v_av);
[~ , index] = max(P);
count = 0;
for i = 1:size(X,2)
   if index(i) == y(i)
      count = count+1;
   end
end
acc = 100 * count/size(X,2);
end


function [J,loss] = ComputeCost(varargin)
X = varargin{1};
Y = varargin{2}; 
W = varargin{3};
b = varargin{4}; 
gamma = varargin{5};
beta = varargin{6};
lambda = varargin{7};

if nargin == 9
    mu_av = varargin{1,8};
    v_av = varargin{1,9};
    [P, ~] = EvaluateClassifier(X, W, b, gamma, beta, mu_av, v_av);
else
    [P, ~] = EvaluateClassifier(X, W, b, gamma, beta);
end
    
layer = size(W,2);
Wsum = 0;
Lcross = (-Y.*log(P))/size(X,2);
loss = sum(sum(Lcross));
for i = 1:layer
    Wsum = Wsum + sumsqr(W{i});
end
J = loss + (lambda * Wsum);
end
%Gradient computation
function [grad_W, grad_b, grad_G, grad_Be] = ComputeGradients(X, Y, P, Xb, s, scap, W, gamma, mu, v, lambda)

N = size(X,2);
I = ones(N,1);
layer = size(W,2);
grad_W = cell(1,layer);
grad_b = cell(1,layer);
grad_G = cell(1,layer-1);
grad_Be = cell(1,layer-1);

G = -(Y-P);
grad_W{layer} = (G*(Xb{layer-1})')/N + 2*lambda*W{layer};
grad_b{layer} = (G*I)/N;
G = W{layer}'*G;
Xtemp = Xb{layer-1};
Xtemp(Xtemp>0) = 1;
G = G .* Xtemp;

for l = layer-1:-1:1
    grad_G{l} = ((G.*scap{l})*I)/N;
    grad_Be{l} = (G*I)/N;
    G = G.*(gamma{l}*I');
    G = BatchNormBackPass(G,s{l}, mu{l}, v{l});
    if(l==1)
        grad_W{l} = (G*(X)')/N + (2*lambda*W{l});
        grad_b{l} = (G*I)/N;
    else
        grad_W{l} = (G*(Xb{l-1})')/N + (2*lambda*W{l});
        grad_b{l} = (G*I)/N;
    end
    if (l>1)
      G = W{l}'*G;
      Xtemp = Xb{l-1};
      Xtemp(Xtemp>0) = 1;
      G = G .* Xtemp;
    end
end
end

function Gbatch = BatchNormBackPass(G,s, mu, v)
N = size(G,2);
I = ones(N,1);
sig1 = (v+eps).^(-0.5);
sig2 = (v+eps).^(-1.5);
G1 = G.*(sig1*I');
G2 = G.*(sig2*I');
D = s - mu*I';
c = (G2.*D)*I;
p1 = ((G1*I)*I')/N;
p2 = (D.*(c*I'))/N;
Gbatch = G1 - p1 - p2;
end

%Evaluating Classifier function
function [P, Xb, s, scap, mu, v] = EvaluateClassifier(varargin)
%the b vector gets repmat'ed during the addition process,so no repmat fn is explicitly used
X = varargin{1};
W = varargin{2};
b = varargin{3};
gamma = varargin{4};
beta = varargin{5};
layer = size(W,2);
N = size(X,2);
s= cell(1,layer);
mu= cell(1,layer-1);
v = cell (1,layer-1);
scap = cell(1,layer-1);
sbar = cell(1,layer-1);
Xb = cell(1,layer-1);

if nargin == 7
    mu = varargin{6};
    v = varargin{7};
    for l = 1: layer-1
       if l == 1
           s{l} = W{l}*X + b{l};
       else
           s{l} = W{l}*Xb{l-1}+ b{l};
       end
       scap{l} = ((diag (v{l}+eps))^-0.5) * (s{l} - mu{l});
       sbar{l} = gamma{l}.*scap{l} + beta{l};
       Xb{l} = max(0,sbar{l});
    end
    s{layer} = W{layer} * Xb{layer-1} + b{layer};
    exp_s = exp(s{layer});
    sum_s = sum(exp_s);
    P = exp_s ./ sum_s;
else
    for l = 1: layer-1
       if l == 1
           s{l} = W{l}*X + b{l};
       else
           s{l} = W{l}*Xb{l-1}+ b{l};
       end
       
       mu{l} = sum(s{l},2)/N;
       v{l} = (sum((s{l}- mu{l}).^2 , 2))/N;
       
       scap{l} = ((diag (v{l}+eps))^-0.5) * (s{l} - mu{l});
       sbar{l} = gamma{l}.*scap{l} + beta{l};
       Xb{l} = max(0,sbar{l});
    end
    s{layer} = W{layer} * Xb{layer-1} + b{layer};
    exp_s = exp(s{layer});
    sum_s = sum(exp_s);
    P = exp_s ./ sum_s;
end

end

function [W, b, gamma, beta] = initialize(m,K,d)
rng(400);
layer = size(m,2)+1;
W = cell(1,layer);
b = cell(1,layer);
gamma = cell(1,layer-1);
beta = cell(1,layer-1);
for i = 1:layer
    if (i==1)
        W{i} = randn(m(i),d) * sqrt(2/d);
        b{i} = zeros(m(i),1);
        gamma{i} = ones(m(i),1);
        beta{i} = zeros(m(i),1);
    elseif (i==layer)
        W{i} = randn(K,m(i-1)) * sqrt(2/(m(i-1)));
        b{i} = zeros(K,1);
    else
        W{i} = randn(m(i),m(i-1))* sqrt(2/(m(i-1)));
        b{i} = zeros(m(i),1);
        gamma{i} = ones(m(i),1);
        beta{i} = zeros(m(i),1);
    end    
end
end

function [X, Y, y] = LoadBatch(filename)
A = load(filename);
X = (double(A.data'))/255;
y = double(A.labels') + 1;
Y = zeros(max(y),size(X,2));
for i=1:size(X,2)
    temp = y(i);
    for j = 1:max(y)
        if (temp == j)
            Y(j,i) = 1;
        end
    end
end
end

