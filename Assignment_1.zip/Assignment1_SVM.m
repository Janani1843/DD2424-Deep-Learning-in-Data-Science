%Loading and Storing data
[Xt, Yt, yt] = LoadBatch('data_batch_1');
[Xv, Yv, yv] = LoadBatch('data_batch_2');
[Xc, Yc, yc] = LoadBatch ('test_batch.mat');

%Data normalization
mean_X = mean(Xt, 2);
std_X = std(Xt, 0, 2);
Xt = Xt - repmat(mean_X, [1, size(Xt, 2)]);
Xt = Xt ./ repmat(std_X, [1, size(Xt, 2)]);
Xv = Xv - repmat(mean_X, [1, size(Xv, 2)]);
Xv = Xv ./ repmat(std_X, [1, size(Xv, 2)]);
Xc = Xc - repmat(mean_X, [1, size(Xc, 2)]);
Xc = Xc ./ repmat(std_X, [1, size(Xc, 2)]);

%Initial values for W and b
rng(400);
W = randn(10,3072) * 0.01;
%b = randn(10,1) * 0.01;
b= 1;
lambda = 0;
GDparams = struct;
GDparams.eta = 0.01;
GDparams.n_batch = 100;
GDparams.n_epoch = 40;
Jt = zeros(1,GDparams.n_epoch);
Jv = zeros(1,GDparams.n_epoch);
for k = 1: GDparams.n_epoch
    Jt(k) = ComputeCost(Xt, Yt, W, b, lambda);
    Jv(k) = ComputeCost(Xv, Yv, W, b, lambda);
    [W,b] = MiniBatchGD(Xt, Yt, GDparams, W, b, lambda);
end
acc_train = ComputeAccuracy(Xt, yt, W, b);
acc_valid = ComputeAccuracy(Xv, yv, W, b);
acc_test = ComputeAccuracy(Xc, yc, W, b);
figure(1)
plot(1:GDparams.n_epoch, Jt, 'r')
hold on
plot(1:GDparams.n_epoch, Jv, 'g')
hold off
xlabel('epoch');
ylabel('loss');
legend('training loss', 'validation loss');
figure(2)
for i=1:10
    im = reshape(W(i, :), 32, 32, 3);
    s_im{i} = (im - min(im(:))) / (max(im(:)) - min(im(:)));
    s_im{i} = permute(s_im{i}, [2, 1, 3]);
end
montage(s_im, 'Size', [1 10]);


function [X, Y, y] = LoadBatch(filename)
A = load(filename);
X = (double(A.data'))/255;
y = double(A.labels') + 1;
Y = zeros(max(y),size(X,2));
for i=1:size(X,2)
    temp = y(i);
    for j = 1:max(y)
        if (temp == j)
            Y(j,i) = 1;
        end
    end
end
end

%Evaluating Classifier function
function s = EvaluateClassifier(X,W,b)
%the b vector gets repmat'ed during the addition process,so no repmat fn is explicitly used
s = W*X + b;
end

%Cost function computation
function J = ComputeCost(X, Y, W, b, lambda)
s = EvaluateClassifier(X,W,b);
sc = repmat(sum(s.*Y), size(s, 1), 1);
comparison = s - sc + 1;
new = max(0,comparison);
new_sum = sum(new(find(new ~= 1)));
J = (lambda * sumsqr(W)) + (new_sum/size(X,2));
end

%Accuracy function
function acc = ComputeAccuracy(X, y, W, b)
P = EvaluateClassifier(X,W,b);
[~ , index] = max(P);
count = 0;
for i = 1:size(X,2)
   if index(i) == y(i)
      count = count+1;
   end
end
acc = 100 * count/size(X,2);
end

function [grad_W, grad_b] = ComputeGradients(X, Y,s,W,lambda)
N = size(X,2);
I = ones(N,1);
sc = repmat(sum(s.*Y), size(s, 1), 1);
margin = s - sc + 1;
loss = max(0,margin);
G = zeros(size(loss));
G(find(margin > 0)) = 1;
G(find(Y == 1)) = -1;
grad_W = G * X'; 
grad_W = 2*lambda*W + grad_W/N;
grad_b = (G * I)/N;
end

%Implementation of mini-bathc gradient descent
function [Wstar, bstar] = MiniBatchGD(X, Y, GDparams, W, b, lambda)

for j= 1: (size(X,2)/GDparams.n_batch)
    j_start = (j-1)*GDparams.n_batch + 1;
    j_end = j*GDparams.n_batch;
    inds = j_start:j_end;
    Xbatch = X(:, inds);
    Ybatch = Y(:, inds);
    Pbatch = EvaluateClassifier(Xbatch,W,b);
    [grad_Wo, grad_bo] = ComputeGradients(Xbatch, Ybatch, Pbatch, W, lambda);
    W = W - GDparams.eta*grad_Wo;
    b = b - GDparams.eta*grad_bo;
end

Wstar = W;
bstar = b;
end


