%Loading and Storing data
filename = {'data_batch_1','data_batch_2','data_batch_3','data_batch_4','data_batch_5'};
[Xc, Yc, yc] = LoadBatch('test_batch');
for i = (1:5)
    [X, Y, y] = LoadBatch(char(filename(i)));
    if (i == 1)
        Xt = X;
        yt = y;
        Yt = Y;
    elseif(i~=1 && i~=5) 
        Xt = [Xt X];
        Yt = [Yt Y];
        yt = [yt y];
    end
    if (i==5)
        Xv = X(:,9001:10000);
        Yv = Y(:,9001:10000);
        yv = y(:,9001:10000);
        X = X(:,1:9000);
        Y = Y(:,1:9000);
        y = y(:,1:9000);
        Xt = [Xt X];
        Yt = [Yt Y];
        yt = [yt y];
    end
    
end
%Data normalization
mean_X = mean(Xt, 2);
std_X = std(Xt, 0, 2);
Xt = Xt - repmat(mean_X, [1, size(Xt, 2)]);
Xt = Xt ./ repmat(std_X, [1, size(Xt, 2)]);
Xv = Xv - repmat(mean_X, [1, size(Xv, 2)]);
Xv = Xv ./ repmat(std_X, [1, size(Xv, 2)]);
Xc = Xc - repmat(mean_X, [1, size(Xc, 2)]);
Xc = Xc ./ repmat(std_X, [1, size(Xc, 2)]);

m = 50; %number of hidden nodes
K = max(yt); %number of classes
d = size(Xt,1);
N = size(Xt,2);
[W, b] = initialize(m,K,d);

GDparams = struct;
GDparams.eta_min = 1e-5;
GDparams.eta_max = 1e-1;
GDparams.n_batch = 100;
GDparams.cycles = 3;
GDparams.updateStep =2*floor(N/GDparams.n_batch);
GDparams.eta = zeros(1,(2*GDparams.cycles*GDparams.updateStep));
GDparams.lambda = 0.00143357836105457;

[W, b, GDparams, Jt, Jv, lt, lv, acc_t, acc_v] = MiniBatchGD(Xt, Yt, yt, Xv, Yv, yv, GDparams, W, b);
acc_test = ComputeAccuracy(Xc, yc, W, b);
xaxis = (0:100:2*GDparams.cycles*GDparams.updateStep);
learning = (1:1:2*GDparams.cycles*GDparams.updateStep);
figure(1)
plot(xaxis, Jt, 'r')
hold on
plot(xaxis, Jv, 'g')
hold off
xlabel('update step');
ylabel('cost');
legend('training cost', 'validation cost');
figure(2)
plot(xaxis, lt, 'r')
hold on
plot(xaxis, lv, 'g')
hold off
xlabel('update step');
ylabel('loss');
legend('training loss', 'validation loss');
figure(3)
plot(xaxis, acc_t, 'r')
hold on
plot(xaxis, acc_v, 'g')
hold off
xlabel('update step');
ylabel('accuracy');
legend('training accuracy', 'validation accuracy');

function [W, b, GDparams, Jt, Jv, lt, lv, acc_t, acc_v] = MiniBatchGD(X, Y, y, Xv, Yv, yv, GDparams, W, b)
Jt = zeros(1,30); lt = zeros(1,30); acc_t = zeros(1,30);
Jv = zeros(1,30); lv = zeros(1,30); acc_v = zeros(1,30);
count = 1;
dataSize = size(X,2);
for i = 1 : 2*GDparams.cycles*GDparams.updateStep
    for L = 0:GDparams.cycles
        if((i>=(2*L*GDparams.updateStep)) && (i<= ((2*L+1)*GDparams.updateStep)))
            e1 = (i - (2*L*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_min + (e1*e2);
        elseif((i >= ((2*L+1)*GDparams.updateStep)) && (i<=(2*(L+1)*GDparams.updateStep)))
            e1 = (i - ((2*L+1)*GDparams.updateStep))/GDparams.updateStep;
            e2 =  GDparams.eta_max - GDparams.eta_min;
            GDparams.eta(i) = GDparams.eta_max - (e1*e2);
        end
    end
    
    if (i <= dataSize/GDparams.n_batch)
        j = i;
    elseif (i>dataSize/GDparams.n_batch)
        j = rem(i,dataSize/GDparams.n_batch);
        if (j == 0)
            j = dataSize/GDparams.n_batch;
        end
    end
    if (i==1 || rem(i,GDparams.n_batch) == 0)
        [Jt(count),lt(count)]  = ComputeCost(X, Y, W, b, GDparams.lambda);
        [Jv(count),lv(count)]  = ComputeCost(Xv, Yv, W, b, GDparams.lambda);
        acc_t(count) = ComputeAccuracy(X, y, W, b);
        acc_v(count) = ComputeAccuracy(Xv, yv, W, b); 
        count = count +1;
    end
    j_start = (j-1)*GDparams.n_batch + 1;
    j_end = j*GDparams.n_batch;
    inds = j_start:j_end;
    Xbatch = X(:, inds);
    Ybatch = Y(:, inds);
    [Pbatch,Hbatch] = EvaluateClassifier(Xbatch,W,b);
    [grad_W, grad_b] = ComputeGradients(Xbatch, Ybatch, Pbatch, Hbatch, W, GDparams.lambda);
    W{1} = W{1} - GDparams.eta(i)*grad_W{1};
    b{1} = b{1} - GDparams.eta(i)*grad_b{1};
    W{2} = W{2} - GDparams.eta(i)*grad_W{2};
    b{2} = b{2} - GDparams.eta(i)*grad_b{2};
    
end
end

function acc = ComputeAccuracy(X, y, W, b)
P = EvaluateClassifier(X,W,b);
[~ , index] = max(P);
count = 0;
for i = 1:size(X,2)
    if index(i) == y(i)
        count = count+1;
    end
end
acc = 100 * count/size(X,2);
end

%Gradient computation
function [grad_W, grad_b] = ComputeGradients(X, Y, P, H, W, lambda)
W1 = W{1};
W2 = W{2};
N = size(X,2);
I = ones(N,1);
G = -(Y-P);
grad_W2 = ((G*H')/N) + (2*lambda*W2);
grad_b2 = (G*I)/N;
G = W2' * G;
H(H>0) = 1;
G = G.*H;
grad_W1 = ((G*X')/N) + (2*lambda*W1);
grad_b1 = (G*I)/N;
grad_W = {grad_W1, grad_W2};
grad_b = {grad_b1, grad_b2};
end


function [cost,loss]  = ComputeCost(X, Y, W, b, lambda)
W1 = W{1};
W2 = W{2};
[P, ~] = EvaluateClassifier(X, W, b);
Lcross = (-Y.*log(P))/size(X,2);
loss = sum(sum(Lcross));
cost = loss + (lambda * (sumsqr(W1)+ sumsqr(W2)));
end
%Evaluating Classifier function
function [P,H] = EvaluateClassifier(X, W, b)
%the b vector gets repmat'ed during the addition process,so no repmat fn is explicitly used
W1 = W{1};
W2 = W{2};
b1 = b{1};
b2 = b{2};
s1 = W1*X + b1;
H = max(0,s1);
s = W2*H + b2;
exp_s = exp(s);
sum_s = sum(exp_s);
P = exp_s ./ sum_s;
end

function [W, b] = initialize(m,K,d)
W1 = randn(m,d) * (1/sqrt(d));
W2 = randn(K,m) * (1/sqrt(m));
b1 = zeros(m,1);
b2 = zeros(K,1);
W = {W1, W2};
b = {b1, b2};
end

function [X, Y, y] = LoadBatch(filename)
A = load(filename);
X = (double(A.data'))/255;
y = double(A.labels') + 1;
Y = zeros(max(y),size(X,2));
for i=1:size(X,2)
    temp = y(i);
    for j = 1:max(y)
        if (temp == j)
            Y(j,i) = 1;
        end
    end
end
end

