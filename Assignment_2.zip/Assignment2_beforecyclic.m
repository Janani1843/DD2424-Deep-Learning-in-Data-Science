%Loading and Storing data
[Xt, Yt, yt] = LoadBatch('data_batch_1');
[Xv, Yv, yv] = LoadBatch('data_batch_2');
[Xc, Yc, yc] = LoadBatch ('test_batch.mat');

%Data normalization
mean_X = mean(Xt, 2);
std_X = std(Xt, 0, 2);
Xt = Xt - repmat(mean_X, [1, size(Xt, 2)]);
Xt = Xt ./ repmat(std_X, [1, size(Xt, 2)]);
Xv = Xv - repmat(mean_X, [1, size(Xv, 2)]);
Xv = Xv ./ repmat(std_X, [1, size(Xv, 2)]);
Xc = Xc - repmat(mean_X, [1, size(Xc, 2)]);
Xc = Xc ./ repmat(std_X, [1, size(Xc, 2)]);
m = 50; %number of hidden nodes
K = max(yt); %number of classes
d = size(Xt,1);
lambda = 0;
[W, b] = initialize(m,K,d);
[P,H] = EvaluateClassifier(Xt, W, b);
GDparams = struct;
GDparams.eta = 0.001;
GDparams.n_batch = 100;
GDparams.n_epoch = 200;
Jt = zeros(1,GDparams.n_epoch);
X = Xt(:,100);
Y = Yt(:,100);
y = yt(1:100);
for k = 1: GDparams.n_epoch
    Jt(k) = ComputeCost(X, Y, W, b, lambda);
    [P, H] = EvaluateClassifier(X,W,b);
    [grad_W, grad_b] = ComputeGradients(X, Y, P, H, W, lambda);
    W{1} = W{1} - GDparams.eta*grad_W{1};
    b{1} = b{1} - GDparams.eta*grad_b{1};
    W{2} = W{2} - GDparams.eta*grad_W{2};
    b{2} = b{2} - GDparams.eta*grad_b{2};
end
acc_train = ComputeAccuracy(X, y, W, b);
figure(1)
plot(1:GDparams.n_epoch, Jt, 'r')
xlabel('epoch');
ylabel('loss');
legend('training loss');

function acc = ComputeAccuracy(X, y, W, b)
P = EvaluateClassifier(X,W,b);
[~ , index] = max(P);
count = 0;
for i = 1:size(X,2)
   if index(i) == y(i)
      count = count+1;
   end
end
acc = 100 * count/size(X,2);
end

%Gradient computation
function [grad_W, grad_b] = ComputeGradients(X, Y, P, H, W, lambda)
W1 = W{1};
W2 = W{2};
N = size(X,2);
I = ones(N,1);
G = -(Y-P);
grad_W2 = ((G*H')/N) + (2*lambda*W2);
grad_b2 = (G*I)/N;
G = W2' * G;
H(H>0) = 1;
G = G.*H;
grad_W1 = ((G*X')/N) + (2*lambda*W1);
grad_b1 = (G*I)/N;
grad_W = {grad_W1, grad_W2};
grad_b = {grad_b1, grad_b2};
end


function J = ComputeCost(X, Y, W, b, lambda)
W1 = W{1};
W2 = W{2};
[P, ~] = EvaluateClassifier(X, W, b);
Lcross = (-Y.*log(P))/size(X,2);
J = sum(sum(Lcross)) + (lambda * (sumsqr(W1)+ sumsqr(W2)));
end
%Evaluating Classifier function
function [P,H] = EvaluateClassifier(X, W, b)
%the b vector gets repmat'ed during the addition process,so no repmat fn is explicitly used
W1 = W{1};
W2 = W{2};
b1 = b{1};
b2 = b{2};
s1 = W1*X + b1;
H = max(0,s1);
s = W2*H + b2;
exp_s = exp(s);
sum_s = sum(exp_s);
P = exp_s ./ sum_s;
end

function [W, b] = initialize(m,K,d)
rng(400);
W1 = randn(m,d) * (1/sqrt(d));
W2 = randn(K,m) * (1/sqrt(m));
b1 = zeros(m,1);
b2 = zeros(K,1);
W = {W1, W2};
b = {b1, b2};
end

function [X, Y, y] = LoadBatch(filename)
A = load(filename);
X = (double(A.data'))/255;
y = double(A.labels') + 1;
Y = zeros(max(y),size(X,2));
for i=1:size(X,2)
    temp = y(i);
    for j = 1:max(y)
        if (temp == j)
            Y(j,i) = 1;
        end
    end
end
end

function [error_W1,error_W2,error_b1,error_b2] = gradient_error(X, Y, m, K, d, lambda)
h = 1e-5;
[W, b] = initialize(m,K,d);
[P,H] = EvaluateClassifier(X, W, b);
[agW,agb] = ComputeGradients(X, Y, P, H, W, lambda);
[ngW,ngb] = ComputeGradsNumSlow(X, Y, W, b, lambda, h);
epsilon = 0.00001;
for i = 1:4
    error_b1(i) = max(abs(agb{1}-ngb{1})./max(epsilon,abs(agb{1})+abs(ngb{1})));
    error_W1(i) = max(max(max(abs(agW{1}-ngW{1}))./max(epsilon,abs(agW{1})+abs(ngW{1}))));
    error_b2(i) = max(abs(agb{2}-ngb{2})./max(epsilon,abs(agb{2})+abs(ngb{2})));
    error_W2(i) = max(max(max(abs(agW{2}-ngW{2}))./max(epsilon,abs(agW{2})+abs(ngW{2}))));
    epsilon = epsilon*10;
end
end

function [grad_W, grad_b] = ComputeGradsNumSlow(X, Y, W, b, lambda, h)


grad_W = cell(numel(W), 1);
grad_b = cell(numel(b), 1);

for j=1:length(b)
    grad_b{j} = zeros(size(b{j}));
    
    for i=1:length(b{j})
        
        b_try = b;
        b_try{j}(i) = b_try{j}(i) - h;
        c1 = ComputeCost(X, Y, W, b_try, lambda);
        
        b_try = b;
        b_try{j}(i) = b_try{j}(i) + h;
        c2 = ComputeCost(X, Y, W, b_try, lambda);
        
        grad_b{j}(i) = (c2-c1) / (2*h);
    end
end

for j=1:length(W)
    grad_W{j} = zeros(size(W{j}));
    
    for i=1:numel(W{j})
        
        W_try = W;
        W_try{j}(i) = W_try{j}(i) - h;
        c1 = ComputeCost(X, Y, W_try, b, lambda);
    
        W_try = W;
        W_try{j}(i) = W_try{j}(i) + h;
        c2 = ComputeCost(X, Y, W_try, b, lambda);
    
        grad_W{j}(i) = (c2-c1) / (2*h);
    end
end
end